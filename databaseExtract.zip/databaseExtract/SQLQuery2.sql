﻿DELETE  FROM rental
 